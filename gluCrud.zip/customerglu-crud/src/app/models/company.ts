export class CompanyProfile {
  id: string;
  companyName: string;
  companyAddress: string;
  email: string;
  phoneNumber: any;
  employeeInfo: Array<EmployeeInfo>;

  constructor(formData: any, id: string) {
    this.id = id ? id : Math.random().toString(16).slice(2);
    this.companyName = formData.companyName;
    this.companyAddress = formData.companyAddress;
    this.email = formData.email;
    this.phoneNumber = formData.phoneNumber
    this.employeeInfo = [new EmployeeInfo(formData.employeeInfo)]
  }
}

export class EmployeeInfo {
  employeeName: string;
  designation: string;
  joinDate: string;
  email: string;
  phoneNumber: any;
  skillsInfo: Array<SkillInfo>;
  eductionInfo: Array<EducationInfo>;

  constructor(formData: any) {
    this.employeeName = formData.employeeName;
    this.designation = formData.designation;
    this.joinDate = formData.joinDate;
    this.email = formData.email;
    this.phoneNumber = formData.phoneNumber;
    this.skillsInfo = [formData.skillsInfo]
    this.eductionInfo = [formData.educationInfo]
  }
}

export interface SkillInfo {
  skillName: string;
  skillRating: string;
}

export interface EducationInfo {
  instituteName: string;
  courseName: string;
  completedYear: string;
}