import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CompanyProfile } from '../models/company';
import { DataService } from '../service/data.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-new-company',
  templateUrl: './new-company.component.html',
  styleUrls: ['./new-company.component.scss']
})
export class NewCompanyComponent implements OnInit {
  id: string = '';
  loading = false;
  maxDate = new Date().setDate(new Date().getDate() - 1);
  panelOpenState: any;
  companyProfile: FormGroup = new FormGroup({
    companyName: new FormControl('', [Validators.required]),
    companyAddress: new FormControl('', []),
    email: new FormControl('', [Validators.required]),
    phoneNumber: new FormControl('', [Validators.required]),
    employeeInfo: new FormGroup({
      employeeName: new FormControl('', [Validators.required]),
      designation: new FormControl('', [Validators.required]),
      joinDate: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required]),
      phoneNumber: new FormControl('', [Validators.required]),
      skillsInfo: new FormGroup({
        skillName: new FormControl('', [Validators.required]),
        skillRating: new FormControl('', [Validators.required])
      }),
      educationInfo: new FormGroup({
        instituteName: new FormControl('', [Validators.required]),
        courseName: new FormControl('', [Validators.required]),
        completedYear: new FormControl('', [Validators.required])
      })
    })
  });

  constructor(private dataService: DataService, private _snackBar: MatSnackBar, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params: any) => {
      if (params.companyId) {
        this.id = params.companyId;
        this.loading = true;
        this.dataService.getCompanyById(params.companyId).then((company: any) => {
          this.updateFormFields(company);
        });
      }
    })
  }

  onSubmitForm() {
    if (!this.companyProfile.valid) {
      return;
    }
    this.loading = true;
    if (this.id) {
      this.dataService.updateCompany(new CompanyProfile(this.companyProfile.value, this.id)).then((res) => {
        this._snackBar.open('Company saved successfully.', 'Dismiss');
        this.loading = false;
      });
    } else {
      this.dataService.saveCompany(new CompanyProfile(this.companyProfile.value, this.id)).then((res) => {
        this._snackBar.open('Company saved successfully.', 'Dismiss');
        this.loading = false;
      });
    }
  }

  updateFormFields(companyDetails: any) {
    const empDetails = companyDetails.employeeInfo[0];
    const eductionInfo = companyDetails.employeeInfo[0].eductionInfo[0];
    const skillsInfo = companyDetails.employeeInfo[0].skillsInfo[0];
    this.companyProfile.patchValue(
      {
        companyName: companyDetails.companyName,
        companyAddress: companyDetails.companyAddress,
        email: companyDetails.email,
        phoneNumber: companyDetails.phoneNumber,
        employeeInfo: {
          employeeName: empDetails.designation,
          email: empDetails.email,
          phoneNumber: empDetails.phoneNumber,
          joinDate: empDetails.joinDate,
          designation: empDetails.designation,
          skillsInfo: {
            skillName: skillsInfo.skillName,
            skillRating: skillsInfo.skillRating,
          },
          educationInfo: {
            completedYear: eductionInfo.completedYear,
            courseName: eductionInfo.courseName,
            instituteName: eductionInfo.instituteName,
          },
        },
      });
    this.loading = false;
  }
}
