import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyListComponent } from './company-list/company-list.component';

const routes: Routes = [
  { path: '', redirectTo: 'company-list', pathMatch: 'full' }, // configure the default route for app i.e company-list when valid empty route
  { path: 'company-list', component: CompanyListComponent }, // landing page no need to configure the lazy loading
  { path: 'new-company', loadChildren: () => import("./new-company/new-company.module").then((m) => m.NewCompanyModule) }, // lazy loading route, this moudle downloades when click on new company tab.
  { path: '**', redirectTo: 'company-list', pathMatch: 'full' } // configure the default route for app i.e company-list when invalid route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
