import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { DataService } from 'src/app/service/data.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { CompanyProfile } from 'src/app/models/company';
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogueComponent } from '../shared/components/confirm-dialogue/confirm-dialogue.component';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.scss']
})
export class CompanyListComponent implements OnInit {
  loading = false;
  displayedColumns = ['companyName', 'companyAddress', 'email', 'phoneNumber', 'actions'];
  dataSource: any;
  companyData: any;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  constructor(public dataService: DataService, private _snackBar: MatSnackBar, private router: Router, public dialog: MatDialog) { }

  updatePaginatorAndSort() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnInit(): void {
    this.loadData();
    this.dataService.dataChange.subscribe((res) => {
      if (res) {
        this.dataSource = new MatTableDataSource(res);
        this.updatePaginatorAndSort();
      }
    });
  }

  editCompany(id: string) {
    this.router.navigate(['/new-company'], { queryParams: { companyId: id } })
  }

  deleteCompany(id: string, name: string) {
    const dialogRef = this.dialog.open(ConfirmDialogueComponent, {
      width: '40%',
      data: { name: name },
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loading = true;
        this.dataService.deleteCompany(id).then((res) => {
          this.loading = false;
          this._snackBar.open('Company deleted successfully.', 'Dismiss');
        });
      }
    });
  }

  searchEvent(event: any) {
    const filteredData = this.dataService.data.slice().filter((com: CompanyProfile) => {
      const searchStr = (com.companyName + com.companyAddress + com.email + com.phoneNumber).toLowerCase();
      return searchStr.indexOf(event.target.value.toLowerCase()) !== -1;
    });
    this.dataSource = new MatTableDataSource(filteredData);
    this.updatePaginatorAndSort();
  }

  loadData() {
    this.dataService.getAllCompanies();
  }
}
