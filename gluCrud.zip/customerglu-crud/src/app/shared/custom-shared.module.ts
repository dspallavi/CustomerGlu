import { NgModule } from '@angular/core';
import { AngularMaterialModule } from './angular-material/angular-material.module';
import { ConfirmDialogueComponent } from './components/confirm-dialogue/confirm-dialogue.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
    declarations: [
        ConfirmDialogueComponent
    ],
    imports: [
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule,
        AngularMaterialModule
    ],
    exports: [AngularMaterialModule, ConfirmDialogueComponent]
})
export class CustomSharedModule { }
